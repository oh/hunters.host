(function () {



/* Exports */
Package._define("dev-error-overlay");

})();
