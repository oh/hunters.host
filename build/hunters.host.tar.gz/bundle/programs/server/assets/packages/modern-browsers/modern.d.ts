export declare function setMinimumBrowserVersions(
  versions: Record<string, number | number[]>,
  source: string
): void;
